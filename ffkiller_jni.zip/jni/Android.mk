LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := SignatureKiller
LOCAL_SRC_FILES := mt_jni_ffguard.c xhook.c xh_core.c xh_elf.c xh_log.c xh_util.c xh_version.c
LOCAL_CFLAGS := -Wall -Wextra -fvisibility=hidden
LOCAL_LDLIBS := -llog
include $(BUILD_SHARED_LIBRARY)
